from django.urls import path
from . import views

urlpatterns = [
    path('chatbot', views.chatbot, name='chatbot'),
    path('login', views.login, name='login'),
    path('register', views.register, name='register'),
    path('logout', views.logout, name='logout'),
    path('new_chat', views.new_chat, name='new_chat'),  # New chat route
]
