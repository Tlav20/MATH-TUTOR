from django.shortcuts import render, redirect  
from django.http import JsonResponse  
import openai  

from django.contrib import auth  # Django authentication
from django.contrib.auth.models import User  
from .models import Chat  # Chat model to save chat logs

from django.utils import timezone  # To get the current time

# Set up OpenAI API key
openai_api_key = ''
openai.api_key = openai_api_key

# Ask OpenAI with a given message and return the cleaned answer
def ask_openai(message):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an helpful assistant."},
            {"role": "user", "content": message},
        ]
    )
    answer = response.choices[0].message.content.strip()
    return answer

# Chatbot view: handles chat submissions and renders chat history
def chatbot(request):
    chats = Chat.objects.filter(user=request.user)

    if request.method == 'POST':
        message = request.POST.get('message')
        response = ask_openai(message)

        # Save the user's message and the response from OpenAI
        chat = Chat(user=request.user, message=message, response=response, created_at=timezone.now())
        chat.save()
        return JsonResponse({'message': message, 'response': response})
    return render(request, 'chatbot.html', {'chats': chats})

# Login view: authenticates and logs in the user
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(request, username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('chatbot')
        else:
            error_message = 'Invalid username or password'
            return render(request, 'login.html', {'error_message': error_message})
    return render(request, 'login.html')

# Register view: creates a new user account and logs them in
def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 == password2:
            try:
                user = User.objects.create_user(username, email, password1)
                user.save()
                auth.login(request, user)
                return redirect('chatbot')
            except:
                error_message = 'Error creating account'
                return render(request, 'register.html', {'error_message': error_message})
        else:
            error_message = 'Password dont match'
            return render(request, 'register.html', {'error_message': error_message})
    return render(request, 'register.html')

# Logout view: logs out the current user and redirects to login page
def logout(request):
    auth.logout(request)
    return redirect('login')

# NEW: Start a new chat by clearing previous messages
from django.views.decorators.http import require_POST

@require_POST
def new_chat(request):
    if request.user.is_authenticated:
        Chat.objects.filter(user=request.user).delete()
    return redirect('chatbot')